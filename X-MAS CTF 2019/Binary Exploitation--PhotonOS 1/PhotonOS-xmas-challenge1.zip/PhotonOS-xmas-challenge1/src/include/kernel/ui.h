#ifndef _ui_h
#define _ui_h

#include <system.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <phapi.h>

void prompt();
void welcome();
void logo();
void login();

#endif
