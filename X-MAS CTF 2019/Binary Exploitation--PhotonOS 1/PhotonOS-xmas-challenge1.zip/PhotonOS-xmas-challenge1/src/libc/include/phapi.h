#ifndef _phapi_h
#define _phapi_h

// include all Photon API headers
#include <system.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/cdefs.h>
#include <list.h>
#include <linked_list.h>
#include <bitmap.h>
#include <graph.h>
#include <stack.h>

// types & structs of Photon API

// function declarations of phapi.c

#endif
