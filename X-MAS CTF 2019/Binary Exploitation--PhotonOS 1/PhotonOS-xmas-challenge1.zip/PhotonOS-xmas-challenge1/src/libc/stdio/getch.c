#include <system.h>
#include <stdio.h>
#include <string.h>
#include <phapi.h>
#include <sys/cdefs.h>

int getch()
{
    // to be implemented with syscalls
    return -1;
}
