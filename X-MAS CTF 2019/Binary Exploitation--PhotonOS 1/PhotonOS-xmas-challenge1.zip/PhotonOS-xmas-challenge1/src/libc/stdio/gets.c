#include <system.h>
#include <stdio.h>
#include <string.h>
#include <phapi.h>
#include <sys/cdefs.h>

char *gets(char *str)
{
    // to be implemented with syscalls
    return NULL;
}
