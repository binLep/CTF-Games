from Crypto.Util.number import bytes_to_long as b2l
from gmpy2 import *
from random import *

M_weak = 4014476939333036189094441199026045136645885247730

def get_prime():
    while True:
        k = randint(2**18, 2**19-1) # get k
        a = randint(2**20, 2**62-1) # random a
        p = k * M_weak + pow(2**16+1, a, M_weak)

        if is_prime(p):
            return p

def generate_key():
    p = get_prime()
    q = get_prime()
    n = p * q
    return n

if __name__ == '__main__':
    n = generate_key()

    flag = b2l(open("flag.txt").read())

    ct = pow(flag, 65537, n)

    print (n, ct)
