<?php
$config = [
	'db'=>'dmbs335',
	'username'=>'gatecrasher',
	'password'=>'[redacted]',
];
?>
