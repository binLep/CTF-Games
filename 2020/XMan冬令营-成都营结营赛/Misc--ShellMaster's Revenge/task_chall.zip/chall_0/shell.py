import os
import sys
import time

blacklist = []
for i in range(0, 10):
	blacklist += str(i)
blacklist += '/'
print "Blacklist: ",
print blacklist

def handler():
	print "Oops, you looks like a beginner."
	os._exit(0)

print "Welcome to Shell Master's Revenge!"
print "I hate numbers so I banned all of them!"
print "Start to wake up the shell ..."
time.sleep(3)
sys.stdout.flush()

while True:
	sys.stdout.write("beginner@ubuntu:~$ ")
	sys.stdout.flush()
	cmd = raw_input().upper()

	for i in blacklist:
		if i in cmd:
			print "blacklist: "+i
			handler()

	cmd += " 2>&1"
	print os.system(cmd)
