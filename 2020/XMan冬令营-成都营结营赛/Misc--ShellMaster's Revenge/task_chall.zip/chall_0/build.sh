#!/bin/sh

docker build -t "shellmaster_revenge" .
