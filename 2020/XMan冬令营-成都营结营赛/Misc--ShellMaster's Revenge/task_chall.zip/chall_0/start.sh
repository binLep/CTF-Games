#!/bin/sh

sleep 1

socat TCP4-LISTEN:8200,fork EXEC:'python -u /home/ctf/shell.py'

/bin/bash
