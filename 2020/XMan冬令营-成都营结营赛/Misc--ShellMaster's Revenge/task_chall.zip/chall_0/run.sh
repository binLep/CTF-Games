docker run -d -p 8200:8200 shellmaster_revenge
