res = [0x52, 0x69, 0x73, 0x69, 0x6e, 0x67, 0x5f, 0x48, 0x6f, 0x70, 0x70, 0x65, 0x72, 0x21, 0x52, 0x69, 0x73, 0x69]

for i in range(0, len(res)):
    res[i] = chr(res[i])

out = [''] * 0x100
str_enc = list(''.join(res))
str_dec = [17, 8, 6, 10, 15, 20, 42, 59, 47, 3, 47, 4, 16, 72, 62, 0, 7, 16]
Str = list(' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~')
print Str
for j in range(0, len(str_dec)):
    for i in range(0, len(Str)):
        tmp1 = ord(Str[i])
        cache1 = ord(str_enc[j % 14])
        haha1 = ~(tmp1 & cache1)
        haha2 = tmp1 | cache1
        tmp = haha1 & haha2
        if tmp == str_dec[j]:
            print j
            print hex(str_dec[j])[2:]
            print hex(haha1)
            print hex(tmp1 | cache1)[2:]
            print Str[i] + ' : ' + hex(ord(Str[i]))[2:]
            print str_enc[j] + ' : ' + hex(ord(str_enc[j]))[2:]
            out.append(Str[i])
            # raw_input()
out = ''.join(out)
print out
print len(res)
# Caucasus@s_ability

print res