import java.util.Scanner;

public class hanhan {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner in =new Scanner(System.in);
        String yours;
        String people="ZmxhZ3tZb3UgYXJlIHNpbXBsZSBhbmQgaG9uZXN0fQ==";



    }

}
