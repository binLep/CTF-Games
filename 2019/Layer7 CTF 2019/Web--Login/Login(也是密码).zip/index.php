<?php
session_start(); // session needed

require(dirname(__FILE__).DIRECTORY_SEPARATOR."config.php");
require(dirname(__FILE__).DIRECTORY_SEPARATOR."functions.php");

define("MAIN_PAGE", true);
define("SUPER_USER", "panghoddari");

$input = file_get_contents('php://input');

$header = custom_read("header");
$footer = custom_read("footer");

$format = $header[1]."%s".$footer[1];
unset($header, $footer); // unset variables

$contents = '';
if ($input) {
	$input = urldecode($input);
	$input = base64_decode($input);

	if (preg_match('/index|functions|config/i', $input)) $input = '';
	$input = str_replace('=', '', $input);
	$input = str_replace('&', '', $input);
	$input = explode("//", $input);

	$page  = $input[0];
	$type  = $input[1];

	define("USER", html_escape($input[2]));
	define("PASS", html_escape($input[3]));
	unset($input); // unset variable

	$data  = custom_read($page, $type);
	if (is_debug() && $data) 
		$contents .= sprintf("<!--".PHP_EOL."- Debug Information: ".PHP_EOL."%s".PHP_EOL."-->", $data[0]);
	$contents .= $data[1];
}else {
	$data  = custom_read("main");
	$contents .= $data[1];
}

printf($format, $contents);