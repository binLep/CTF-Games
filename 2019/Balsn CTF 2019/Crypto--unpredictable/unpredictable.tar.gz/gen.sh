for i in `seq 1 3`
do
    python3 gen.py > output.$i.txt
done
